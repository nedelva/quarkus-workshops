package io.quarkus.workshop.superheroes.load;
